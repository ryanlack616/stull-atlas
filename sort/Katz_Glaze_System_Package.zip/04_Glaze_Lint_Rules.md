
# Glaze Lint Rules (Katz-Aligned)

## Required
- Explicit boron source
- UMF calculated
- Cone range declared
- Fluxes identified

## Warnings
- Excess B2O3
- High Na2O/K2O at cone 6
- Low Al2O3
- High expansion risk

## Errors
- Unknown materials
- Missing LOI
- No durability evidence
