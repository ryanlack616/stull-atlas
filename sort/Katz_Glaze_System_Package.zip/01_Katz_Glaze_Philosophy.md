
# Matt Katz and the Modern Glaze Chemistry Framework

## Overview
Matt Katz’s contribution to ceramics lies not in inventing specific glazes, but in reframing how glazes are understood, constructed, tested, and modified. His work emphasizes chemistry-first thinking, durability, repeatability, and the separation of artistic intent from chemical implementation.

## Key Contributions
- Treating glazes as oxide systems rather than recipes
- Emphasizing boron control at mid-range temperatures
- Promoting durability and leach resistance as design constraints
- Encouraging test-driven glaze development
- Bridging studio practice with material science

## Philosophical Position
Katz consistently advocates that glaze formulation should be:
- Intentional
- Measurable
- Testable
- Reproducible
- Chemically coherent

This philosophy strongly influenced modern glaze pedagogy and tools.
