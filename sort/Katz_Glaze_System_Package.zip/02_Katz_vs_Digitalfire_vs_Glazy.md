
# Katz vs Digitalfire vs Glazy

## Matt Katz / Ceramic Materials Workshop
- Focus: Studio translation of glaze chemistry
- Strength: Explaining *why* glazes behave as they do
- Method: Empirical + chemical modeling
- Emphasis: Durability, boron control, mid-range behavior

## Digitalfire
- Focus: Comprehensive ceramic materials reference
- Strength: Depth, precision, materials science
- Method: Reference-based engineering documentation
- Emphasis: Defects, materials, process control

## Glazy
- Focus: Computation and sharing
- Strength: Rapid iteration and comparison
- Method: Community-driven recipe modeling
- Limitation: Depends on quality of input data

## Summary
Katz = Interpretation + Teaching
Digitalfire = Reference + Engineering
Glazy = Computation + Workflow
