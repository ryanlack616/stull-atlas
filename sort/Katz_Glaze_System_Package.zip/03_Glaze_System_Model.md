
# Katz-Inspired Glaze System Model

## Layer 1: Intent
- Surface quality
- Durability requirements
- Firing range
- Color goals

## Layer 2: Chemical Targets
- UMF values
- SiO2 / Al2O3 ratio
- Boron content
- Flux balance

## Layer 3: Implementation
- Raw materials
- Substitutions
- LOI
- Application thickness

## Layer 4: Evidence
- Firing logs
- Durability tests
- Visual results
- Failure documentation

## Principle
Recipes are not truth.
Measured outcomes are.
