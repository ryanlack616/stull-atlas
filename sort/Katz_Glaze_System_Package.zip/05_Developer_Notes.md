
# Developer Notes

This model maps cleanly to a rule-based or compiler-style system.

Suggested pipeline:
1. Input recipe
2. Normalize materials
3. Compute UMF
4. Validate chemistry
5. Apply Katz rules
6. Generate warnings
7. Require evidence

Ideal for:
- Glaze engines
- Ceramic CAD systems
- Educational software
- Studio QA pipelines
