
NCECA FOUNDATIONAL ARCHIVE — CHECKPOINT PACKAGE

This package contains everything needed to resume work on the
NCECA Exhibitions + Panels archival project.

CONTENTS
---------
1. NCECA_Foundational_Archive_v2.zip
   - Exhibitions dataset (2023–2025)
   - Panels dataset (2023–2025)
   - CSV format, normalized
   - Source-cited and verified

2. PROJECT_STATE.json
   - Scope decisions
   - Data rules
   - What has and has not been done
   - Next recommended steps

PROJECT STATUS
--------------
✓ Exhibitions extracted (2023–2025)
✓ Panels extracted (2023–2025)
✓ Accuracy-first methodology
✓ Source citations preserved
✓ Transcript layer not yet expanded
✓ Talks/lectures not yet included

WHAT HAS NOT BEEN DONE
---------------------
- Transcript extraction
- Video/caption scraping
- Journal cross-referencing
- Pre-2023 ingestion
- Public-facing formatting

HOW TO CONTINUE
---------------
1. Load the CSVs
2. Continue panel extraction or transcript mapping
3. Expand to earlier years if desired
4. Optionally build a database or API

This checkpoint represents a stable archival baseline.
