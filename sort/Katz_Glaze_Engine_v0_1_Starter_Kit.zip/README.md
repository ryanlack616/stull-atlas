# Katz Glaze Engine v0.1 (Starter Kit)

Intent → Chemistry Target → Implementation → Evidence

Included:
- JSON Schema (`schema/glaze_project.schema.json`)
- Katz-aligned lint pack (`schema/lint_rules.katz_v01.json`)
- Example project (`examples/example_glaze_project.json`)
- RFC-style spec (`docs/RFC_Katz_Glaze_Engine_v0.1.md`)

Next steps:
- materials database (oxide analyses + LOI)
- UMF calculator + expansion estimate
- executable rule engine (turn lint metadata into checks)
- blend plan generator
