# Katz-Style Glaze Engine Spec (v0.1)
_Date: 2026-01-24_

This spec models glaze development as an **intent → chemistry → implementation → evidence** pipeline.

Goal: standardize **meaning** (intent/chemistry/evidence), not aesthetics.

## Core objects
- **GlazeProject**: container
- **Intent**: cone/atmosphere, functional class, surface target
- **ChemistryTarget**: UMF ranges/targets + derived ratios; boron explicit at mid-range
- **Implementation**: materials + parts + process + substitutions
- **Evidence**: firings + tests + photos; upgrades “candidate” → “validated”

## Compiler-style pipeline
A) Intake/Normalize → B) Compute UMF/ratios → C) Lint/Validate → D) Plan blends/tests → E) Reports

## Authority model
Recipe text is not authoritative for functional claims; **evidence is**.

See:
- `schema/glaze_project.schema.json`
- `schema/lint_rules.katz_v01.json`
- `examples/example_glaze_project.json`
