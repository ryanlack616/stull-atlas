from __future__ import annotations
import argparse
from glaze_engine.io import load_json, write_json, write_text, write_csv
from glaze_engine.materials import load_materials_db, load_aliases, resolve_material
from glaze_engine.substitutions import apply_substitutions
from glaze_engine.chemistry import compute_chemistry
from glaze_engine.lint import lint
from glaze_engine.report import summarize_markdown
from glaze_engine.interop import export_glazy, export_insight_csv_rows
from glaze_engine.optimize import generate_optimized_path
from glaze_engine.oxide_influence import compute_oxide_influence, influence_markdown

def main():
    ap = argparse.ArgumentParser(description="Katz Glaze Engine v0.7 — locks + multi-sinks + oxide influence.")
    ap.add_argument("project_json")
    ap.add_argument("--materials", default="materials_db/materials.json")
    ap.add_argument("--aliases", default="materials_db/aliases.json")
    ap.add_argument("--schema", default="schema/glaze_project.schema.json")
    ap.add_argument("--out", default="reports")
    ap.add_argument("--optiblends", action="store_true")
    ap.add_argument("--blend_steps", type=int, default=7)
    ap.add_argument("--export_glazy", action="store_true")
    ap.add_argument("--export_insight", action="store_true")
    ap.add_argument("--oxide_influence", action="store_true")
    args = ap.parse_args()

    project_raw = load_json(args.project_json)
    project, applied_subs = apply_substitutions(project_raw)

    mdb = load_json(args.materials)
    adb = load_json(args.aliases)
    schema = load_json(args.schema)

    materials = load_materials_db(mdb)
    aliases = load_aliases(adb)

    def lookup(name: str):
        return resolve_material(name, materials, aliases)

    chem = compute_chemistry(project["implementation"]["ingredients"], lookup)
    chem_json = {"oxide_weights": chem.oxide_weights, "oxide_moles": chem.oxide_moles, "umf": chem.umf, "ratios": chem.ratios}

    issues = lint(project, chem_json, schema=schema, material_lookup=lookup, applied_subs=applied_subs)

    pid = project.get("project", {}).get("id", "UNKNOWN_PROJECT")
    write_json(f"{args.out}/{pid}.chemistry.json", chem_json)
    write_json(f"{args.out}/{pid}.lint.json", {"project_id": pid, "issues": issues, "substitutions_applied": applied_subs})
    write_text(f"{args.out}/{pid}.summary.md", summarize_markdown(project, chem_json, issues, applied_subs=applied_subs))

    if args.export_glazy or args.export_insight:
        exp_dir = f"{args.out}/exports"
        if args.export_glazy:
            write_json(f"{exp_dir}/{pid}.glazy.json", export_glazy(project, chem_json))
        if args.export_insight:
            write_csv(f"{exp_dir}/{pid}.insight.csv", export_insight_csv_rows(chem_json))

    if args.optiblends:
        out_dir = f"{args.out}/blends/{pid}"
        recipes, meta = generate_optimized_path(project, lookup, steps=args.blend_steps)
        if recipes is None:
            write_text(f"{out_dir}/multi_target_OPT_NOTE.md", f"# Optimized multi-target\n\n{meta.get('note','optimizer failed')}\n")
        else:
            base_mats = [i["material"] for i in project["implementation"]["ingredients"]]
            rows = [["step","b2o3_target","b2o3_achieved","si_al_target","si_al_achieved","d_b","d_s","inc_boron","inc_silica","decrease_sinks","score"] + base_mats]
            for idx, step_meta in enumerate(meta["meta_per_step"]):
                parts_map = {r["material"]: float(r["parts"]) for r in recipes[idx]}
                rows.append([
                    idx+1,
                    round(step_meta["b_target"],6),
                    round(step_meta["b_achieved"],6),
                    round(step_meta["sa_target"],6),
                    round(step_meta["sa_achieved"],6),
                    round(step_meta["d_b"],4),
                    round(step_meta["d_s"],4),
                    step_meta["increase_boron"],
                    step_meta["increase_silica"],
                    ";".join(step_meta["decrease_sinks"]),
                    round(step_meta["score"],8),
                ] + [round(parts_map.get(m,0.0),4) for m in base_mats])
            write_csv(f"{out_dir}/multi_target_optimized.csv", rows)
            write_text(f"{out_dir}/multi_target_optimized.md",
                       "# Optimized multi-target path\n\n"
                       "Respects lock_materials and distributes decreases across decrease_pool.\n"
                       "Tune intent.constraints.optimizer.* to control behavior.\n")

    if args.oxide_influence:
        inf = compute_oxide_influence(project, lookup, applied_subs=applied_subs)
        write_json(f"{args.out}/{pid}.oxide_influence.json", inf)
        # focus on key oxides first
        md = influence_markdown(inf, oxides=["B2O3","Na2O","K2O","SiO2","Al2O3","CaO","MgO","ZnO","Li2O","Fe2O3","TiO2"])
        write_text(f"{args.out}/{pid}.oxide_influence.md", md)

    has_err = any(i.get("severity") == "error" for i in issues)
    if has_err:
        raise SystemExit(2)

if __name__ == "__main__":
    main()
