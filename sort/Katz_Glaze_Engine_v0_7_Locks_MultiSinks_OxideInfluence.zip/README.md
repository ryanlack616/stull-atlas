# Katz Glaze Engine v0.7 (Locked Sets + Multi-Sinks + Oxide Confidence Influence)
_Date: 2026-01-24_

Upgrades from v0.6:
- **Locked ingredient sets**: declare ingredients the optimizer must not change (`lock_materials`).
- **Multiple decrease sinks**: optimizer can distribute decreases across multiple ingredients (`decrease_pool`).
- **Oxide confidence influence report**: estimates which ingredient uncertainty dominates each oxide
  (B2O3, Na2O, K2O, SiO2, Al2O3, CaO, etc.) based on contribution share × effective confidence.

## Quick start
```bash
pip install -r requirements.txt
python cli.py examples/example_cone6_satin.json --out reports --optiblends --export_glazy --export_insight --oxide_influence
```

## New outputs
- `reports/<id>.oxide_influence.json`
- `reports/<id>.oxide_influence.md`
- `reports/blends/<id>/multi_target_optimized.csv` (now respects locked sets + multi-sinks)

## Configuration (project JSON)
Under `intent.constraints.optimizer`:
- `lock_materials`: list of material names that must remain unchanged
- `decrease_pool`: list of materials allowed to be decreased (defaults to feldspar-like)
- `min_parts`: per-material minimums (still supported)
- `max_parts`: per-material maximums (still supported)
- `max_total_delta_frac`: total allowable increase budget as fraction of total parts
- `lock_clay_fraction`: keep total clay parts stable (optional)
