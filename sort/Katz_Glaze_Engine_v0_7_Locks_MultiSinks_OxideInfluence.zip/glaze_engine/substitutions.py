from __future__ import annotations
from typing import Dict, Any, Tuple, List
import json

def apply_substitutions(project: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    impl = project.get("implementation", {}) or {}
    subs = impl.get("substitutions") or []
    if not subs:
        return project, []
    mapping = {}
    for s in subs:
        frm = s.get("from_material")
        to = s.get("to_material")
        loss = float(s.get("confidence_loss", 0.0) or 0.0)
        if frm and to:
            mapping[frm] = (to, loss, s.get("notes",""))
    new = json.loads(json.dumps(project))
    applied = []
    for ing in new.get("implementation", {}).get("ingredients", []):
        m = ing.get("material")
        if m in mapping:
            to, loss, notes = mapping[m]
            ing["material"] = to
            applied.append({"from": m, "to": to, "confidence_loss": loss, "notes": notes})
    return new, applied
