from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List

MOLAR_MASS = {
    "SiO2": 60.0843,
    "Al2O3": 101.9613,
    "B2O3": 69.619,
    "Na2O": 61.9789,
    "K2O": 94.196,
    "CaO": 56.0774,
    "MgO": 40.3044,
    "ZnO": 81.379,
    "Li2O": 29.8814,
    "Fe2O3": 159.688,
    "TiO2": 79.866,
}

FLUX_OXIDES = {"Na2O","K2O","CaO","MgO","ZnO","Li2O"}

@dataclass
class ChemistryResult:
    oxide_weights: Dict[str, float]
    oxide_moles: Dict[str, float]
    umf: Dict[str, float]
    ratios: Dict[str, float]

def compute_oxide_weights(ingredients: List[Dict], material_lookup) -> Dict[str, float]:
    totals: Dict[str, float] = {}
    for ing in ingredients:
        mat = material_lookup(ing["material"])
        parts = float(ing["parts"])
        for ox, pct in mat.oxides_wt_percent.items():
            totals[ox] = totals.get(ox, 0.0) + parts * (pct / 100.0)
    return totals

def compute_moles(oxide_weights: Dict[str, float]) -> Dict[str, float]:
    out = {}
    for ox, w in oxide_weights.items():
        mm = MOLAR_MASS.get(ox)
        if mm:
            out[ox] = w / mm
    return out

def compute_umf(oxide_moles: Dict[str, float]) -> Dict[str, float]:
    flux = sum(oxide_moles.get(ox, 0.0) for ox in FLUX_OXIDES)
    if flux <= 0:
        return {}
    return {ox: mol/flux for ox, mol in oxide_moles.items()}

def compute_chemistry(ingredients: List[Dict], material_lookup) -> ChemistryResult:
    ow = compute_oxide_weights(ingredients, material_lookup)
    om = compute_moles(ow)
    umf = compute_umf(om)
    si, al, b = umf.get("SiO2",0.0), umf.get("Al2O3",0.0), umf.get("B2O3",0.0)
    ratios = {}
    if al > 0:
        ratios["SiO2_Al2O3"] = si/al
        ratios["B2O3_Al2O3"] = (b/al) if b>0 else 0.0
    return ChemistryResult(ow, om, umf, ratios)
