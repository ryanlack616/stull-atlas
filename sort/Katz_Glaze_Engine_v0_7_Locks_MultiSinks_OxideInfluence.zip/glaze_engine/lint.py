from __future__ import annotations
from typing import Any, Dict, List
from datetime import datetime, date
from .schema_validate import validate_minimal, validate_with_jsonschema
from .materials import effective_confidence

def _as_of_date(project: Dict[str, Any]) -> date:
    try:
        s = project.get("project", {}).get("created_date")
        if s:
            return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        pass
    return date.today()

def lint(project: Dict[str, Any], chemistry: Dict[str, Any], schema: Dict[str, Any] | None, material_lookup=None, applied_subs=None) -> List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    try:
        issues.extend(validate_with_jsonschema(project, schema) if schema else validate_minimal(project))
    except Exception:
        issues.extend(validate_minimal(project))

    def add(code, severity, message, path=""):
        issues.append({"code":code,"severity":severity,"message":message,"path":path})

    if applied_subs:
        for s in applied_subs:
            add("SUB_W700","warning", f"Substitution applied: {s['from']} -> {s['to']} (confidence_loss={s['confidence_loss']})", "implementation.substitutions")

    if material_lookup is not None:
        as_of = _as_of_date(project)
        bridge_loss_by_mat = {}
        if applied_subs:
            for s in applied_subs:
                bridge_loss_by_mat[s["to"]] = max(float(s["confidence_loss"]), bridge_loss_by_mat.get(s["to"], 0.0))
        low = []
        for ing in project.get("implementation", {}).get("ingredients", []):
            try:
                mat = material_lookup(ing["material"])
                loss = bridge_loss_by_mat.get(mat.name, 0.0)
                c = effective_confidence(mat, as_of, bridge_loss=loss)
                if c < 0.6:
                    low.append((mat.name, c))
            except Exception:
                continue
        if low:
            add("DATA_W600","warning",
                "Low-confidence material analyses (incl. substitution bridge loss): " + ", ".join([f"{n} ({c:.2f})" for n,c in sorted(low, key=lambda x: x[1])]),
                "materials_db")

    # locked materials sanity check
    constraints = (((project.get("intent", {}) or {}).get("constraints", {}) or {}).get("optimizer", {}) or {})
    lock = constraints.get("lock_materials") or []
    if lock:
        add("OPT_I800","info", f"Optimizer lock_materials active: {', '.join(lock)}", "intent.constraints.optimizer.lock_materials")

    return issues
