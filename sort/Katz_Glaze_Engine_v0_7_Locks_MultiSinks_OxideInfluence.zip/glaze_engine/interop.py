from __future__ import annotations
from typing import Dict, Any

def export_glazy(project: Dict[str, Any], chemistry: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "format": "glazy_like_v1",
        "project_id": project.get("project", {}).get("id"),
        "name": project.get("project", {}).get("name"),
        "cone": project.get("intent", {}).get("firing", {}).get("cone"),
        "atmosphere": project.get("intent", {}).get("firing", {}).get("atmosphere"),
        "ingredients": [{"material": i.get("material"), "parts": i.get("parts")} for i in project.get("implementation", {}).get("ingredients", [])],
        "computed": {"umf": chemistry.get("umf", {}), "ratios": chemistry.get("ratios", {})}
    }

def export_insight_csv_rows(chemistry: Dict[str, Any]) -> list[list]:
    ow = chemistry.get("oxide_weights", {})
    om = chemistry.get("oxide_moles", {})
    umf = chemistry.get("umf", {})
    oxides = sorted(set(list(ow.keys()) + list(om.keys()) + list(umf.keys())))
    rows = [["oxide", "weight_parts", "moles", "umf"]]
    for ox in oxides:
        rows.append([ox, round(float(ow.get(ox,0.0) or 0.0),6), round(float(om.get(ox,0.0) or 0.0),8), round(float(umf.get(ox,0.0) or 0.0),6)])
    return rows
