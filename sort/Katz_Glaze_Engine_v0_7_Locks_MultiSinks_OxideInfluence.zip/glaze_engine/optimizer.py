
from .chemistry import compute_chemistry
import random, math

def optimize(project, materials, targets, constraints):
    base = project["implementation"]["ingredients"]
    locked = set(constraints.get("locked_ingredients", []))

    # identify sinks & sources
    inc = [i for i in base if "frit" in i["material"].lower()]
    dec = [i for i in base if i["material"] not in locked]

    best = None
    best_state = None

    for _ in range(1500):
        test = [dict(i) for i in base]
        for i in test:
            if i["material"] in locked: continue
            delta = random.uniform(-3,3)
            i["parts"] = max(0.1, i["parts"] + delta)

        chem = compute_chemistry(test, materials)
        err = abs(chem.umf.get("B2O3",0)-targets["b2o3"]) +               abs(chem.ratios.get("SiO2_Al2O3",0)-targets["si_al"])

        if best is None or err < best:
            best = err
            best_state = test

    return best_state, best
