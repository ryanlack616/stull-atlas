from __future__ import annotations
from typing import Dict, Any, List
from datetime import datetime, date
from .materials import effective_confidence

def _as_of_date(project: Dict[str, Any]) -> date:
    try:
        s = project.get("project", {}).get("created_date")
        if s:
            return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        pass
    return date.today()

def compute_oxide_influence(project: Dict[str, Any], material_lookup, applied_subs=None) -> Dict[str, Any]:
    """Estimate which ingredient uncertainty dominates each oxide.
    For each oxide, we compute each ingredient's contribution share (by oxide weight parts).
    Then compute an 'uncertainty weight' = share * (1 - effective_confidence).
    Higher means that ingredient is a larger uncertainty driver for that oxide.
    """
    as_of = _as_of_date(project)

    bridge_loss_by_mat = {}
    if applied_subs:
        for s in applied_subs:
            bridge_loss_by_mat[s["to"]] = max(float(s["confidence_loss"]), bridge_loss_by_mat.get(s["to"], 0.0))

    ings = project.get("implementation", {}).get("ingredients", [])
    # per-ingredient oxide contributions
    contrib = {}  # oxide -> {material: weight_parts}
    totals = {}   # oxide -> total weight_parts
    confidences = {}  # material -> effective_confidence

    for ing in ings:
        mname = ing["material"]
        mat = material_lookup(mname)
        loss = bridge_loss_by_mat.get(mat.name, 0.0)
        confidences[mname] = effective_confidence(mat, as_of, bridge_loss=loss)
        parts = float(ing["parts"])
        for ox, pct in mat.oxides_wt_percent.items():
            w = parts * (pct/100.0)
            contrib.setdefault(ox, {})[mname] = contrib.setdefault(ox, {}).get(mname, 0.0) + w
            totals[ox] = totals.get(ox, 0.0) + w

    influence = {}
    for ox, by_mat in contrib.items():
        tot = totals.get(ox, 0.0) or 0.0
        items = []
        for mname, w in by_mat.items():
            share = (w/tot) if tot > 0 else 0.0
            conf = confidences.get(mname, 0.5)
            uncert = share * (1.0 - conf)
            items.append({
                "material": mname,
                "oxide_weight_parts": w,
                "share": share,
                "effective_confidence": conf,
                "uncertainty_weight": uncert
            })
        items.sort(key=lambda x: x["uncertainty_weight"], reverse=True)
        influence[ox] = {
            "total_oxide_weight_parts": tot,
            "top_uncertainty_drivers": items[:5],
            "all": items
        }

    return {
        "as_of": as_of.isoformat(),
        "method": "share*(1-confidence)",
        "influence": influence
    }

def influence_markdown(influence_json: Dict[str, Any], oxides: List[str] | None = None) -> str:
    inf = influence_json.get("influence", {})
    if oxides is None:
        oxides = sorted(inf.keys())
    lines = ["# Oxide Confidence Influence", "", f"As of: {influence_json.get('as_of','')}", f"Method: {influence_json.get('method','')}", ""]
    for ox in oxides:
        if ox not in inf: 
            continue
        lines.append(f"## {ox}")
        lines.append(f"- Total oxide weight parts: {inf[ox].get('total_oxide_weight_parts',0):.4f}")
        top = inf[ox].get("top_uncertainty_drivers", [])
        if not top:
            lines.append("_No drivers computed._")
            lines.append("")
            continue
        for t in top:
            lines.append(f"- {t['material']}: share={t['share']:.3f}, conf={t['effective_confidence']:.3f}, weight={t['uncertainty_weight']:.3f}")
        lines.append("")
    return "\n".join(lines) + "\n"
