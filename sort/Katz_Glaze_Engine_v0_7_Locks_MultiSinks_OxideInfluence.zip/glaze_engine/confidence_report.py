
def build_confidence_report(ingredients, materials):
    report = {}
    for ing in ingredients:
        mat = materials[ing["material"]]
        conf = mat["provenance"]["confidence"]
        for ox, pct in mat["oxides_wt_percent"].items():
            report.setdefault(ox,0)
            report[ox] += pct * conf
    return report
