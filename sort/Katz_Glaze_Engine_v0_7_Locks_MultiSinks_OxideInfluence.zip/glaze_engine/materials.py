from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
from datetime import date, datetime
import math

@dataclass(frozen=True)
class Provenance:
    source: str
    method: str
    date: str
    confidence: float
    half_life_days: float

@dataclass(frozen=True)
class Material:
    name: str
    loi_percent: float
    oxides_wt_percent: Dict[str, float]
    provenance: Optional[Provenance] = None

def _norm(s: str) -> str:
    return " ".join(str(s).strip().split())

def load_materials_db(db: Dict[str, Any]) -> Dict[str, Material]:
    out: Dict[str, Material] = {}
    for m in db.get("materials", []):
        prov = m.get("provenance")
        p_obj = None
        if isinstance(prov, dict):
            p_obj = Provenance(
                source=str(prov.get("source","unknown")),
                method=str(prov.get("method","unknown")),
                date=str(prov.get("date","1970-01-01")),
                confidence=float(prov.get("confidence", 0.5)),
                half_life_days=float(prov.get("half_life_days", 3650)),
            )
        out[_norm(m["name"])] = Material(
            name=_norm(m["name"]),
            loi_percent=float(m.get("loi_percent", 0.0)),
            oxides_wt_percent={k: float(v) for k, v in m.get("oxides_wt_percent", {}).items()},
            provenance=p_obj,
        )
    return out

def load_aliases(alias_obj: Dict[str, Any]) -> Dict[str, str]:
    return {_norm(k): _norm(v) for k, v in alias_obj.get("aliases", {}).items()}

def resolve_material(name: str, materials: Dict[str, Material], aliases: Dict[str, str]) -> Material:
    key = _norm(name)
    key = aliases.get(key, key)
    if key not in materials:
        raise KeyError(f"Unknown material: {name} (resolved '{key}')")
    return materials[key]

def effective_confidence(material: Material, as_of: date, bridge_loss: float = 0.0) -> float:
    base = 0.5
    if material.provenance is not None:
        base = max(0.0, min(1.0, material.provenance.confidence))
        try:
            d0 = datetime.strptime(material.provenance.date, "%Y-%m-%d").date()
        except Exception:
            d0 = date(1970,1,1)
        age_days = max(0, (as_of - d0).days)
        hl = max(1.0, float(material.provenance.half_life_days))
        base = base * (0.5 ** (age_days / hl))
    bridge_loss = max(0.0, min(1.0, float(bridge_loss or 0.0)))
    return base * (1.0 - bridge_loss)
