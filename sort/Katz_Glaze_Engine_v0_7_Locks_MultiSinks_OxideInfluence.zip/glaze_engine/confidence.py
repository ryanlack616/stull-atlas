
from datetime import date, datetime

def effective_confidence(material, bridge_loss=0.0):
    base = material.get("provenance",{}).get("confidence",0.5)
    d = material.get("provenance",{}).get("date","1970-01-01")
    hl = material.get("provenance",{}).get("half_life_days",3650)
    try:
        age = (date.today() - datetime.strptime(d,"%Y-%m-%d").date()).days
    except:
        age = 0
    decay = 0.5 ** (age / max(1,hl))
    return base * decay * (1-bridge_loss)
