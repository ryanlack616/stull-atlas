from __future__ import annotations
from typing import Any, Dict, List

def summarize_markdown(project: Dict[str, Any], chemistry: Dict[str, Any], issues: List[Dict[str, Any]], applied_subs=None) -> str:
    pid = project.get("project", {}).get("id", "UNKNOWN")
    name = project.get("project", {}).get("name", "")
    intent = project.get("intent", {}) or {}
    firing = intent.get("firing", {}) or {}
    func = intent.get("functional_class", "test_only")
    surface = intent.get("surface_target", "unknown")

    lines = [f"# Glaze Card — {pid}"]
    if name:
        lines.append(f"**Name:** {name}")
    lines.append(f"**Intent:** cone {firing.get('cone','?')} {firing.get('atmosphere','?')}, {surface}, class={func}")
    lines.append("")

    if applied_subs:
        lines.append("## Substitutions (Bridges)")
        for s in applied_subs:
            lines.append(f"- {s['from']} → {s['to']} (confidence_loss={s['confidence_loss']})")
        lines.append("")

    lines.append("## Recipe (Implementation)")
    for ing in project.get("implementation", {}).get("ingredients", []):
        lines.append(f"- {ing.get('material')} — {ing.get('parts')} parts")
    lines.append("")

    umf = chemistry.get("umf", {}) or {}
    ratios = chemistry.get("ratios", {}) or {}
    lines.append("## Computed Chemistry (UMF)")
    for ox in ["SiO2","Al2O3","B2O3","Na2O","K2O","CaO","MgO","ZnO","Li2O"]:
        if ox in umf:
            lines.append(f"- {ox}: {umf[ox]:.4f}")
    if ratios:
        lines.append("")
        lines.append("## Derived Ratios")
        for k,v in ratios.items():
            lines.append(f"- {k}: {v:.3f}")

    errs = [i for i in issues if i.get("severity")=="error"]
    warns = [i for i in issues if i.get("severity")=="warning"]
    infos = [i for i in issues if i.get("severity")=="info"]
    lines.append("")
    lines.append("## Lint Summary")
    lines.append(f"- Errors: {len(errs)}")
    lines.append(f"- Warnings: {len(warns)}")
    lines.append(f"- Info: {len(infos)}")
    if warns:
        lines.append("")
        lines.append("### Warnings")
        for w in warns:
            lines.append(f"- **{w['code']}**: {w['message']}")
    if infos:
        lines.append("")
        lines.append("### Info")
        for it in infos:
            lines.append(f"- **{it['code']}**: {it['message']}")

    return "\n".join(lines) + "\n"
