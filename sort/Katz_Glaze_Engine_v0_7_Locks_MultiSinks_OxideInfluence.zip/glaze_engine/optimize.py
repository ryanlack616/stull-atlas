from __future__ import annotations
from typing import Dict, List, Tuple, Optional
from .chemistry import compute_chemistry

def _clone(ings: List[Dict]) -> List[Dict]:
    return [dict(i) for i in ings]

def _total(ings: List[Dict]) -> float:
    return sum(float(i["parts"]) for i in ings)

def _parts_map(ings: List[Dict]) -> dict:
    return {i["material"]: float(i["parts"]) for i in ings}

def _find_candidates(ingredients: List[Dict], material_lookup):
    silica = None; kaolin = None; feldspar = None; boron = None; boron_score = -1.0
    for ing in ingredients:
        name = str(ing.get("material",""))
        mat = material_lookup(name)
        ox = mat.oxides_wt_percent
        lname = name.lower()
        if silica is None and ("silica" in lname or (ox.get("SiO2",0) >= 95 and len(ox) <= 2)):
            silica = ing
        if kaolin is None and ("kaolin" in lname or "epk" in lname or (ox.get("Al2O3",0) >= 30 and ox.get("SiO2",0) >= 30)):
            kaolin = ing
        if feldspar is None and ("feldspar" in lname or ("k2o" in ox and "na2o" in ox and ox.get("SiO2",0) >= 50)):
            feldspar = ing
        b = ox.get("B2O3", 0.0)
        if b > 0 and b > boron_score:
            boron_score = b
            boron = ing
    return silica, kaolin, feldspar, boron

def _targets(project: Dict, base_chem):
    ct = project.get("chemistry_target", {}) or {}
    bor = ct.get("boron", {}) if isinstance(ct, dict) else {}
    ratios = ct.get("ratios", {}) if isinstance(ct, dict) else {}

    b_rng = bor.get("b2o3_umf_range")
    if isinstance(b_rng, list) and len(b_rng)==2:
        bmin, bmax = float(b_rng[0]), float(b_rng[1])
    else:
        b0 = float(base_chem.umf.get("B2O3", 0.0) or 0.0)
        bmin, bmax = max(0.0, b0*0.85), b0*1.15

    sa_rng = ratios.get("si_al_ratio_range")
    if isinstance(sa_rng, list) and len(sa_rng)==2:
        smin, smax = float(sa_rng[0]), float(sa_rng[1])
    else:
        sa0 = float(base_chem.ratios.get("SiO2_Al2O3", 0.0) or 0.0)
        smin, smax = sa0*0.9, sa0*1.1
    return (bmin,bmax),(smin,smax)

def _score(chem, b_target: float, sa_target: float) -> float:
    b = float(chem.umf.get("B2O3",0.0) or 0.0)
    sa = float(chem.ratios.get("SiO2_Al2O3",0.0) or 0.0)
    b_den = max(1e-6, b_target)
    sa_den = max(1e-6, sa_target)
    return ((b-b_target)/b_den)**2 + ((sa-sa_target)/sa_den)**2

def _apply(base: List[Dict], inc_b: str, inc_s: str, decs: List[str], d_b: float, d_s: float, dec_weights: List[float]) -> List[Dict]:
    # distribute decrease across decs according to weights
    out = _clone(base)
    total_dec = d_b + d_s
    # normalize weights
    sw = sum(dec_weights) if dec_weights else 0.0
    weights = [(w/sw) for w in dec_weights] if sw > 0 else [1.0/len(decs)]*len(decs)
    dec_map = {decs[i]: total_dec * weights[i] for i in range(len(decs))}
    for i in out:
        if i["material"] == inc_b:
            i["parts"] = float(i["parts"]) + d_b
        elif i["material"] == inc_s:
            i["parts"] = float(i["parts"]) + d_s
        elif i["material"] in dec_map:
            i["parts"] = max(0.001, float(i["parts"]) - dec_map[i["material"]])
    return out

def _constraint_penalty(ings: List[Dict], base: List[Dict], constraints: Dict) -> float:
    pen = 0.0
    pm = _parts_map(ings)
    base_pm = _parts_map(base)
    # lock materials
    lock = set(constraints.get("lock_materials") or [])
    for m in lock:
        if abs(pm.get(m, base_pm.get(m, 0.0)) - base_pm.get(m, 0.0)) > 1e-6:
            pen += 1e8 * abs(pm.get(m, base_pm.get(m, 0.0)) - base_pm.get(m, 0.0))
    # min/max parts
    min_parts = (constraints.get("min_parts") or {})
    max_parts = (constraints.get("max_parts") or {})
    for k, v in min_parts.items():
        if pm.get(k, 0.0) < float(v):
            pen += 1e6 * (float(v) - pm.get(k,0.0))
    for k, v in max_parts.items():
        if pm.get(k, 0.0) > float(v):
            pen += 1e6 * (pm.get(k,0.0) - float(v))
    return pen

def optimize_multi_target(project: Dict, material_lookup, b_target: float, sa_target: float, constraints: Dict, iters: int = 1800, seed: int = 1):
    base = project["implementation"]["ingredients"]
    silica, kaolin, feldspar, boron = _find_candidates(base, material_lookup)
    if not (silica and boron):
        return None, {"note":"Need boron + silica candidates to optimize."}

    inc_b = boron["material"]
    inc_s = silica["material"]

    # decrease pool
    dec_pool = constraints.get("decrease_pool") or []
    if not dec_pool:
        # fall back to feldspar-like if available, else anything not inc_b/inc_s
        if feldspar:
            dec_pool = [feldspar["material"]]
        else:
            dec_pool = [i["material"] for i in base if i["material"] not in {inc_b, inc_s}]

    # If locked, remove from decrease pool
    lock = set(constraints.get("lock_materials") or [])
    decs = [m for m in dec_pool if m not in lock and m not in {inc_b, inc_s}]
    if not decs:
        return None, {"note":"No eligible decrease sinks after applying lock_materials."}

    total = _total(base)
    max_frac = float(constraints.get("max_total_delta_frac", 0.25))
    dmax = total * max_frac

    lock_clay = bool(constraints.get("lock_clay_fraction", False))
    clay_mats = set()
    if lock_clay:
        for ing in base:
            nm = ing["material"].lower()
            if ("kaolin" in nm or "clay" in nm) or (str(ing.get("role","")).lower() in {"clay","stabilizer"}):
                clay_mats.add(ing["material"])
    base_clay_total = sum(float(i["parts"]) for i in base if i["material"] in clay_mats) if lock_clay else None

    rng = __import__("random").Random(seed)
    best = None
    best_state = None

    # fixed dec weights (equal), but you could extend to optimize them too
    dec_weights = [1.0]*len(decs)

    for t in range(iters):
        d_b = (rng.random()**2) * dmax
        d_s = (rng.random()**2) * dmax
        if t % 60 == 0:
            d_b = rng.random() * dmax
            d_s = rng.random() * dmax

        ings = _apply(base, inc_b, inc_s, decs, d_b, d_s, dec_weights)

        pen = 0.0
        if lock_clay:
            clay_total = sum(float(i["parts"]) for i in ings if i["material"] in clay_mats)
            pen += 1e6 * abs(clay_total - base_clay_total)

        pen += _constraint_penalty(ings, base, constraints)
        chem = compute_chemistry(ings, material_lookup)
        sc = _score(chem, b_target, sa_target) + pen

        if (best is None) or (sc < best):
            best = sc
            best_state = (ings, d_b, d_s, chem)

    ings, d_b, d_s, chem = best_state
    return ings, {
        "increase_boron": inc_b,
        "increase_silica": inc_s,
        "decrease_sinks": decs,
        "d_b": d_b,
        "d_s": d_s,
        "b_target": b_target,
        "b_achieved": float(chem.umf.get("B2O3",0.0) or 0.0),
        "sa_target": sa_target,
        "sa_achieved": float(chem.ratios.get("SiO2_Al2O3",0.0) or 0.0),
        "score": best
    }

def generate_optimized_path(project: Dict, material_lookup, steps: int = 7):
    base_chem = compute_chemistry(project["implementation"]["ingredients"], material_lookup)
    (bmin,bmax),(smin,smax) = _targets(project, base_chem)
    constraints = (((project.get("intent", {}) or {}).get("constraints", {}) or {}).get("optimizer", {}) or {})

    targets = []
    for k in range(steps):
        u = k/(steps-1) if steps>1 else 0.0
        targets.append((bmin + (bmax-bmin)*u, smin + (smax-smin)*u))

    recipes = []
    metas = []
    for b_t, sa_t in targets:
        rec, meta = optimize_multi_target(project, material_lookup, b_t, sa_t, constraints=constraints)
        if rec is None:
            return None, {"note": meta.get("note","opt failed")}
        recipes.append(rec)
        metas.append(meta)
    return recipes, {"targets": targets, "steps": steps, "meta_per_step": metas, "constraints": constraints}
