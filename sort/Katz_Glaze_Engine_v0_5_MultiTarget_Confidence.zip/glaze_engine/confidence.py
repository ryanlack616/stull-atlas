
from datetime import datetime

def compute_confidence(project, chemistry, evidence):
    score = 1.0

    # Evidence presence
    tests = evidence.get("tests", [])
    if not tests:
        score -= 0.25

    # Validation status
    if evidence.get("status") != "validated":
        score -= 0.15

    # Material provenance confidence
    materials = project.get("implementation", {}).get("ingredients", [])
    for m in materials:
        if "confidence" in m and m["confidence"] < 0.8:
            score -= 0.05

    # Chemistry risk heuristics
    umf = chemistry.get("umf", {})
    if umf.get("B2O3", 0) > 0.3:
        score -= 0.1

    if umf.get("SiO2", 0) < 2.0:
        score -= 0.1

    return max(0.0, round(score, 3))
