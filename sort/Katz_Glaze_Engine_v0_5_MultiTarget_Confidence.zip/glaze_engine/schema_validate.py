from __future__ import annotations
from typing import Any, Dict, List

def validate_with_jsonschema(project: Dict[str, Any], schema: Dict[str, Any]) -> List[Dict[str, Any]]:
    import jsonschema
    issues: List[Dict[str, Any]] = []
    validator = jsonschema.Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(project), key=lambda e: e.path):
        path = ".".join([str(p) for p in err.path]) if err.path else ""
        issues.append({"code":"SCHEMA_E000","severity":"error","message":err.message,"path":path})
    return issues

def validate_minimal(project: Dict[str, Any]) -> List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    def err(code,msg,path=""):
        issues.append({"code":code,"severity":"error","message":msg,"path":path})
    intent = project.get("intent", {})
    firing = intent.get("firing", {})
    if "cone" not in firing or "atmosphere" not in firing:
        err("INTENT_E100","Intent must declare firing cone and atmosphere.","intent.firing")
    impl = project.get("implementation", {})
    if not impl.get("ingredients"):
        err("IMPL_E110","Implementation must include at least one ingredient.","implementation.ingredients")
    return issues
