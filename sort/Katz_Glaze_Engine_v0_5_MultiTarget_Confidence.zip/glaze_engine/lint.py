from __future__ import annotations
from typing import Any, Dict, List, Set
from datetime import datetime, date
from .schema_validate import validate_minimal, validate_with_jsonschema
from .materials import effective_confidence

MIDRANGE_CONES = {"4","5","6"}

def _as_of_date(project: Dict[str, Any]) -> date:
    try:
        s = project.get("project", {}).get("created_date")
        if s:
            return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        pass
    return date.today()

def lint(project: Dict[str, Any], chemistry: Dict[str, Any], req_by_intent: Dict[str, List[str]], schema: Dict[str, Any] | None, material_lookup=None) -> List[Dict[str, Any]]:
    issues: List[Dict[str, Any]] = []
    try:
        issues.extend(validate_with_jsonschema(project, schema) if schema else validate_minimal(project))
    except Exception:
        issues.extend(validate_minimal(project))

    intent = project.get("intent", {})
    firing = intent.get("firing", {})
    cone = str(firing.get("cone",""))
    func = intent.get("functional_class","test_only")
    boron = (project.get("chemistry_target", {}) or {}).get("boron", {}) if isinstance(project.get("chemistry_target", {}), dict) else {}

    def add(code, severity, message, path=""):
        issues.append({"code":code,"severity":severity,"message":message,"path":path})

    # Data confidence (warn if any material is low-confidence)
    if material_lookup is not None:
        as_of = _as_of_date(project)
        low = []
        for ing in project.get("implementation", {}).get("ingredients", []):
            try:
                mat = material_lookup(ing["material"])
                c = effective_confidence(mat, as_of)
                if c < 0.6:
                    low.append((mat.name, c))
            except Exception:
                continue
        if low:
            msg = "Low-confidence material analyses: " + ", ".join([f"{n} ({c:.2f})" for n,c in sorted(low, key=lambda x: x[1])])
            add("DATA_W600","warning",msg,"materials_db")

    if cone in MIDRANGE_CONES and not bool(boron.get("explicit_axis", False)):
        add("CHEM_W200","warning","Mid-range glazes should treat boron as an explicit control axis (declare boron axis and source).","chemistry_target.boron")

    evidence = project.get("evidence", {})
    tests = evidence.get("tests") if isinstance(evidence, dict) else None
    if func in {"liner","food_surface","tableware"} and not tests:
        add("EVID_W300","warning","Functional intent declared but no durability/fit evidence is recorded yet.","evidence.tests")

    if isinstance(evidence, dict) and evidence.get("status") == "validated":
        if not any(str(t.get("result","")).lower()=="pass" for t in (tests or [])):
            add("EVID_E301","error","Cannot mark glaze as validated without at least one passing test result.","evidence.status")

    required = set(req_by_intent.get(func, []))
    present: Set[str] = set()
    for t in (tests or []):
        if t.get("test_type"):
            present.add(t["test_type"])
    missing = sorted(list(required - present)) if required else []
    if missing and func in {"liner","food_surface","tableware"}:
        add("EVID_W310","warning",f"Evidence missing required test types for '{func}': {', '.join(missing)}.","evidence.tests")

    # Chemistry risks
    umf = chemistry.get("umf", {})
    b2o3 = float(umf.get("B2O3",0.0) or 0.0)
    na2o = float(umf.get("Na2O",0.0) or 0.0)
    k2o = float(umf.get("K2O",0.0) or 0.0)
    si_al = float(chemistry.get("ratios", {}).get("SiO2_Al2O3", 0.0) or 0.0)

    if cone in MIDRANGE_CONES and b2o3 > 0.25:
        add("RISK_W410","warning",f"High B2O3 UMF ({b2o3:.3f}) at mid-range may soften/gloss-shift or affect color response.","computed.umf.B2O3")
    if si_al and si_al < 5.0:
        add("RISK_W420","warning","Low SiO2:Al2O3 ratio may reduce durability or increase cutlery marking risk.","computed.ratios.SiO2_Al2O3")
    if cone in MIDRANGE_CONES and (na2o + k2o) > 0.6:
        add("RISK_W430","warning","High total alkali UMF (Na2O+K2O) may increase crazing risk and reduce durability.","computed.umf.(Na2O+K2O)")

    return issues
