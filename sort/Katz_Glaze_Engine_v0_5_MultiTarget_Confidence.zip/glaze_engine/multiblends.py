from __future__ import annotations
from typing import Dict, List, Tuple, Optional
from .chemistry import compute_chemistry

def _clone(ings: List[Dict]) -> List[Dict]:
    return [dict(i) for i in ings]

def _total(ings: List[Dict]) -> float:
    return sum(float(i["parts"]) for i in ings)

def _find_candidates(ingredients: List[Dict], material_lookup):
    silica = None; kaolin = None; feldspar = None; boron = None; boron_score = -1.0
    for ing in ingredients:
        name = str(ing.get("material",""))
        mat = material_lookup(name)
        ox = mat.oxides_wt_percent
        lname = name.lower()
        if silica is None and ("silica" in lname or (ox.get("SiO2",0) >= 95 and len(ox) <= 2)):
            silica = ing
        if kaolin is None and ("kaolin" in lname or "epk" in lname or (ox.get("Al2O3",0) >= 30 and ox.get("SiO2",0) >= 30)):
            kaolin = ing
        if feldspar is None and ("feldspar" in lname or ("k2o" in ox and "na2o" in ox and ox.get("SiO2",0) >= 50)):
            feldspar = ing
        b = ox.get("B2O3", 0.0)
        if b > 0 and b > boron_score:
            boron_score = b
            boron = ing
    return silica, kaolin, feldspar, boron

def _apply_deltas(base: List[Dict], inc_b: str, inc_s: str, dec: str, d_b: float, d_s: float) -> List[Dict]:
    out = _clone(base)
    for i in out:
        if i["material"] == inc_b:
            i["parts"] = float(i["parts"]) + d_b
        elif i["material"] == inc_s:
            i["parts"] = float(i["parts"]) + d_s
        elif i["material"] == dec:
            i["parts"] = max(0.001, float(i["parts"]) - (d_b + d_s))
    return out

def _targets(project: Dict, base_chem) -> Tuple[Tuple[float,float], Tuple[float,float]]:
    ct = project.get("chemistry_target", {}) or {}
    bor = ct.get("boron", {}) if isinstance(ct, dict) else {}
    ratios = ct.get("ratios", {}) if isinstance(ct, dict) else {}
    b_rng = bor.get("b2o3_umf_range")
    if isinstance(b_rng, list) and len(b_rng)==2:
        bmin, bmax = float(b_rng[0]), float(b_rng[1])
    else:
        b0 = float(base_chem.umf.get("B2O3", 0.0) or 0.0)
        bmin, bmax = max(0.0, b0*0.85), b0*1.15

    sa_rng = ratios.get("si_al_ratio_range")
    if isinstance(sa_rng, list) and len(sa_rng)==2:
        smin, smax = float(sa_rng[0]), float(sa_rng[1])
    else:
        sa0 = float(base_chem.ratios.get("SiO2_Al2O3", 0.0) or 0.0)
        smin, smax = sa0*0.9, sa0*1.1
    return (bmin,bmax),(smin,smax)

def _score(chem, b_target: float, sa_target: float) -> float:
    b = float(chem.umf.get("B2O3",0.0) or 0.0)
    sa = float(chem.ratios.get("SiO2_Al2O3",0.0) or 0.0)
    # normalized squared error (avoid division by zero)
    b_den = max(1e-6, b_target)
    sa_den = max(1e-6, sa_target)
    return ((b-b_target)/b_den)**2 + ((sa-sa_target)/sa_den)**2

def solve_multi_target_step(project: Dict, material_lookup, b_target: float, sa_target: float,
                            dmax_frac: float = 0.25, grid: int = 26):
    base = project["implementation"]["ingredients"]
    silica, kaolin, feldspar, boron = _find_candidates(base, material_lookup)
    if not (silica and feldspar and boron):
        return None, {"note":"Need boron, silica, and feldspar-like ingredients to solve multi-target."}

    inc_b = boron["material"]
    inc_s = silica["material"]
    dec = feldspar["material"]

    total = _total(base)
    dmax = total * dmax_frac

    best = None
    best_meta = None
    # coarse grid search
    for i in range(grid):
        d_b = dmax * i/(grid-1)
        for j in range(grid):
            d_s = dmax * j/(grid-1)
            ings = _apply_deltas(base, inc_b, inc_s, dec, d_b, d_s)
            chem = compute_chemistry(ings, material_lookup)
            sc = _score(chem, b_target, sa_target)
            if (best is None) or (sc < best):
                best = sc
                best_meta = (ings, d_b, d_s, chem)
    ings, d_b, d_s, chem = best_meta
    return ings, {
        "increase_boron": inc_b,
        "increase_silica": inc_s,
        "decrease": dec,
        "d_b": d_b,
        "d_s": d_s,
        "b_target": b_target,
        "b_achieved": float(chem.umf.get("B2O3",0.0) or 0.0),
        "sa_target": sa_target,
        "sa_achieved": float(chem.ratios.get("SiO2_Al2O3",0.0) or 0.0),
        "score": best
    }

def generate_multi_target_blend(project: Dict, material_lookup, steps: int = 7):
    base_chem = compute_chemistry(project["implementation"]["ingredients"], material_lookup)
    (bmin,bmax),(smin,smax) = _targets(project, base_chem)

    targets = []
    for k in range(steps):
        t = k/(steps-1) if steps>1 else 0.0
        targets.append((bmin + (bmax-bmin)*t, smin + (smax-smin)*t))

    recipes = []
    metas = []
    for b_t, sa_t in targets:
        rec, meta = solve_multi_target_step(project, material_lookup, b_t, sa_t)
        if rec is None:
            return None, {"note": meta.get("note","solver failed")}
        recipes.append(rec)
        metas.append(meta)

    return recipes, {"targets": targets, "steps": steps, "meta_per_step": metas}
