
from __future__ import annotations
from typing import Dict, List
from .chemistry import compute_chemistry

def solve_multi_objective(project, material_lookup, targets, max_iter=200):
    base = project["implementation"]["ingredients"]

    best = None
    best_score = float("inf")

    for i in range(max_iter):
        scale = 1 + (i / max_iter - 0.5) * 0.4

        trial = []
        for ing in base:
            trial.append({
                **ing,
                "parts": max(0.001, ing["parts"] * scale)
            })

        chem = compute_chemistry(trial, material_lookup)
        error = 0.0

        for ox, tgt in targets.items():
            val = chem.umf.get(ox, 0.0)
            error += abs(val - tgt)

        if error < best_score:
            best_score = error
            best = (trial, chem, error)

    return best
