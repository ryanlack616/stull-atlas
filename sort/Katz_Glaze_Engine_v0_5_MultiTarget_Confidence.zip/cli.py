from __future__ import annotations
import argparse
from glaze_engine.io import load_json, write_json, write_text, write_csv
from glaze_engine.materials import load_materials_db, load_aliases, resolve_material
from glaze_engine.chemistry import compute_chemistry
from glaze_engine.lint import lint
from glaze_engine.report import summarize_markdown
from glaze_engine.interop import export_glazy, export_insight_csv_rows
from glaze_engine.multiblends import generate_multi_target_blend

def main():
    ap = argparse.ArgumentParser(description="Katz Glaze Engine v0.5 — UMF, lint, multi-target blends, exports, confidence.")
    ap.add_argument("project_json")
    ap.add_argument("--materials", default="materials_db/materials.json")
    ap.add_argument("--aliases", default="materials_db/aliases.json")
    ap.add_argument("--requirements", default="evidence_protocols/requirements_by_intent_v1.json")
    ap.add_argument("--schema", default="schema/glaze_project.schema.json")
    ap.add_argument("--out", default="reports")
    ap.add_argument("--multiblends", action="store_true", help="Generate multi-target blend path (B2O3 + SiO2:Al2O3)")
    ap.add_argument("--blend_steps", type=int, default=7)
    ap.add_argument("--export_glazy", action="store_true")
    ap.add_argument("--export_insight", action="store_true")
    args = ap.parse_args()

    project = load_json(args.project_json)
    mdb = load_json(args.materials)
    adb = load_json(args.aliases)
    req = load_json(args.requirements)
    schema = load_json(args.schema)

    materials = load_materials_db(mdb)
    aliases = load_aliases(adb)

    def lookup(name: str):
        return resolve_material(name, materials, aliases)

    chem = compute_chemistry(project["implementation"]["ingredients"], lookup)
    chem_json = {"oxide_weights": chem.oxide_weights, "oxide_moles": chem.oxide_moles, "umf": chem.umf, "ratios": chem.ratios}

    issues = lint(project, chem_json, req.get("requirements", {}), schema=schema, material_lookup=lookup)

    pid = project.get("project", {}).get("id", "UNKNOWN_PROJECT")
    write_json(f"{args.out}/{pid}.chemistry.json", chem_json)
    write_json(f"{args.out}/{pid}.lint.json", {"project_id": pid, "issues": issues})
    write_text(f"{args.out}/{pid}.summary.md", summarize_markdown(project, chem_json, issues))

    if args.export_glazy or args.export_insight:
        exp_dir = f"{args.out}/exports"
        if args.export_glazy:
            write_json(f"{exp_dir}/{pid}.glazy.json", export_glazy(project, chem_json))
        if args.export_insight:
            write_csv(f"{exp_dir}/{pid}.insight.csv", export_insight_csv_rows(chem_json))

    if args.multiblends:
        out_dir = f"{args.out}/blends/{pid}"
        recipes, meta = generate_multi_target_blend(project, lookup, steps=args.blend_steps)
        if recipes is None:
            write_text(f"{out_dir}/multi_target_NOTE.md", f"# Multi-target blend\n\n{meta.get('note','solver failed')}\n")
        else:
            base_mats = [i["material"] for i in project["implementation"]["ingredients"]]
            rows = [["step","b2o3_target","b2o3_achieved","si_al_target","si_al_achieved","d_b","d_s","inc_boron","inc_silica","dec"] + base_mats]
            for idx, step_meta in enumerate(meta["meta_per_step"]):
                parts_map = {r["material"]: float(r["parts"]) for r in recipes[idx]}
                rows.append([
                    idx+1,
                    round(step_meta["b_target"],6),
                    round(step_meta["b_achieved"],6),
                    round(step_meta["sa_target"],6),
                    round(step_meta["sa_achieved"],6),
                    round(step_meta["d_b"],4),
                    round(step_meta["d_s"],4),
                    step_meta["increase_boron"],
                    step_meta["increase_silica"],
                    step_meta["decrease"],
                ] + [round(parts_map.get(m,0.0),4) for m in base_mats])
            write_csv(f"{out_dir}/multi_target_blend.csv", rows)
            write_text(f"{out_dir}/multi_target_blend.md",
                       "# Multi-target blend (B2O3 UMF + SiO2:Al2O3)\n\n"
                       "This plan attempts to move along a path between your declared target ranges, solving both targets simultaneously by adjusting boron + silica up while reducing feldspar.\n"
                       "Validate with tiles and evidence screens before any functional claim.\n")

    has_err = any(i.get("severity") == "error" for i in issues)
    if has_err:
        raise SystemExit(2)

if __name__ == "__main__":
    main()
