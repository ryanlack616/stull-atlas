# Katz Glaze Engine v0.5 (Multi-Target Solver + Data Confidence)
_Date: 2026-01-24_

Upgrades from v0.4:
- **Multi-target solver**: adjust multiple ingredients to approach **two targets at once**
  (B2O3 UMF + SiO2:Al2O3 ratio, or B2O3 + SiO2 UMF).
- **Data confidence model** for material analyses:
  - provenance metadata
  - confidence score (0–1)
  - decay half-life (days)
  - runtime "effective confidence" based on age
- Lint adds **DATA_W600** when key materials are low-confidence.

## Quick start
```bash
pip install -r requirements.txt
python cli.py examples/example_cone6_satin.json --out reports --multiblends --export_glazy --export_insight
```

## Outputs
- `reports/<id>.chemistry.json`
- `reports/<id>.lint.json`
- `reports/<id>.summary.md`
- `reports/blends/<id>/multi_target_blend.csv`
- `reports/exports/<id>.glazy.json`
- `reports/exports/<id>.insight.csv`

## What the multi-target solver does (simple + transparent)
It chooses (by heuristic) a *boron* ingredient, a *silica* ingredient, and a *feldspar/other* ingredient.
Then it searches over two deltas:
- +dB to boron source
- +dS to silica source
- -(dB+dS) from the decrease ingredient

So total parts remain stable, while chemistry moves in a controlled direction.
